import React, { useState, useEffect, useRef, memo } from "react";
import { Form, Button } from "react-bootstrap";
import "./Login.css";
import { useQuery, useMutation } from "react-query";
import axios from "axios";
import { gql, useLazyQuery, useQuery as useQueryApollo } from "@apollo/client";
import { GET_USERS, LOGIN_USER } from "../../../graphQL/queries";
import { getCookie, setCookie } from "../../../util/cookies";

function Login() {
  const userRef = useRef();
  const errorRef = useRef();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [data, setData] = useState(null);

  useEffect(() => {
    userRef.current.focus();
  }, []);

  useEffect(() => {
    setError("");
  }, [username, password]);

  useEffect(() => {
    if (success) {
      window.location.href = "/";
    }
  }, [success]);

  const [loginUser] = useLazyQuery(LOGIN_USER, {
    variables: {
      loginInput: {
        username: username,
        password: password,
      },
    },
    onCompleted: (result) => {
      setData(result);
      processUserData(result);
    },
    onError: (error) => {
      setError("Invalid username or password");
      errorRef.current.focus();
    },
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    loginUser();
  };

  const processUserData = (data) => {
    if (data) {
      const accessToken = data.login.token;
      const userData = data.login.user;
      setCookie("loginInfo", JSON.stringify({ accessToken, userData }), 1);
      setSuccess(true);
    }
  };

  const { Control, Label, Group } = Form;
  return (
    <div>
      <h1>Login</h1>
      <Form onSubmit={handleSubmit}>
        <p ref={errorRef} className={"errorMessage " + (!error ? "hidden" : "")}>
          {error}
        </p>
        <Group>
          <Label>Username</Label>
          <Control ref={userRef} type="text" placeholder="Enter username" onChange={(e) => setUsername(e.target.value)} required />
        </Group>
        <Group controlId="formPassword">
          <Label>Password</Label>
          <Control type="password" placeholder="Enter password" onChange={(e) => setPassword(e.target.value)} value={password} required />
        </Group>
        <Button variant="primary" type="submit">
          Login
        </Button>
      </Form>
    </div>
  );
}

export default memo(Login);
